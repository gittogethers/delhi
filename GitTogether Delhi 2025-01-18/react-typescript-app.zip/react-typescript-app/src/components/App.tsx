import React from 'react';
import LogoGenerator from './logo-generator';

function App() {
  return (
    <div className="App">
      <LogoGenerator />
    </div>
  );
}

export default App;